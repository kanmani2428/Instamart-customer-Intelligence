-- Q1

SELECT
    customer_id,
    SUM(order_amount) AS total_spend
FROM orders
WHERE status = 'completed'
  AND order_amount > 500
GROUP BY customer_id
HAVING SUM(order_amount) > 8000;
-- Q2

SELECT
    c.city,
    p.category,
    ROUND(SUM(o.order_amount), 2) AS revenue
FROM orders o
JOIN customers c
    ON o.customer_id = c.customer_id
JOIN products p
    ON o.product_id = p.product_id
WHERE o.status = 'completed'
GROUP BY c.city, p.category
ORDER BY c.city, p.category;
-- Q3

SELECT *
FROM products
WHERE price_inr >
(
    SELECT AVG(price_inr)
    FROM products
);
-- Q4

SELECT
    c.customer_id
FROM customers c
LEFT JOIN orders o
    ON c.customer_id = o.customer_id
    AND o.status = 'completed'
WHERE o.order_id IS NULL;
-- Q5

WITH customer_spend AS
(
    SELECT
        customer_id,
        SUM(order_amount) AS spend
    FROM orders
    WHERE status = 'completed'
    GROUP BY customer_id
)

SELECT *
FROM customer_spend
WHERE spend >
(
    SELECT AVG(spend)
    FROM customer_spend
);
-- Q6

SELECT
    city,
    COUNT(*) AS customers
FROM customers
GROUP BY city
ORDER BY customers DESC;
-- Q7

SELECT
    p.category,
    ROUND(AVG(o.order_amount), 2) AS avg_order_value
FROM orders o
JOIN products p
    ON o.product_id = p.product_id
WHERE o.status = 'completed'
GROUP BY p.category
ORDER BY avg_order_value DESC;