import pandas as pd

# Load cleaned orders data
orders = pd.read_csv("data/clean/orders.csv")

# Keep only completed orders
orders = orders[orders["status"] == "completed"]

# Convert order timestamp to datetime
orders["order_ts"] = pd.to_datetime(orders["order_ts"])

# Reference date for Recency calculation
snapshot_date = orders["order_ts"].max()

print("Latest Order Date:", snapshot_date)

# Build RFM table
rfm = orders.groupby("customer_id").agg(
    Recency=(
        "order_ts",
        lambda x: (snapshot_date - x.max()).days
    ),
    Frequency=(
        "order_id",
        "count"
    ),
    Monetary=(
        "order_amount",
        "sum"
    )
).reset_index()

# Round monetary values
rfm["Monetary"] = rfm["Monetary"].round(2)

# Preview
print("\nRFM Sample:")
print(rfm.head())

print("\nCustomers:", len(rfm))

# Save output
rfm.to_csv(
    "outputs/rfm_table.csv",
    index=False
)

print("\nRFM table saved to outputs/rfm_table.csv")