import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score

# ----------------------------------
# Load RFM Data
# ----------------------------------

rfm = pd.read_csv("outputs/rfm_table.csv")

print("Customers:", len(rfm))

# ----------------------------------
# Create Target Variable
# ----------------------------------

# Customers with Recency > 60 days
# are considered lapsed

rfm["Lapsed"] = (rfm["Recency"] > 60).astype(int)

print("\nTarget Distribution")
print(rfm["Lapsed"].value_counts())

# ----------------------------------
# Features and Target
# ----------------------------------

X = rfm[["Recency", "Frequency", "Monetary"]]
y = rfm["Lapsed"]

# ----------------------------------
# Train / Test Split
# ----------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

# ----------------------------------
# Logistic Regression
# ----------------------------------

lr_model = LogisticRegression(
    max_iter=1000,
    random_state=42
)

lr_model.fit(X_train, y_train)

lr_pred = lr_model.predict(X_test)

lr_accuracy = accuracy_score(y_test, lr_pred)
lr_f1 = f1_score(y_test, lr_pred)

print("\nLogistic Regression")
print("Accuracy:", round(lr_accuracy, 4))
print("F1 Score:", round(lr_f1, 4))

# ----------------------------------
# Random Forest
# ----------------------------------

rf_model = RandomForestClassifier(
    n_estimators=200,
    random_state=42
)

rf_model.fit(X_train, y_train)

rf_pred = rf_model.predict(X_test)

rf_accuracy = accuracy_score(y_test, rf_pred)
rf_f1 = f1_score(y_test, rf_pred)

print("\nRandom Forest")
print("Accuracy:", round(rf_accuracy, 4))
print("F1 Score:", round(rf_f1, 4))

# ----------------------------------
# Select Best Model
# ----------------------------------

if rf_f1 >= lr_f1:
    best_model = rf_model
    best_model_name = "Random Forest"
    best_f1 = rf_f1
else:
    best_model = lr_model
    best_model_name = "Logistic Regression"
    best_f1 = lr_f1

print("\nBest Model:", best_model_name)
print("Best F1:", round(best_f1, 4))

# ----------------------------------
# Save Model
# ----------------------------------

joblib.dump(
    best_model,
    "outputs/lapse_model.joblib"
)

print("\nModel saved:")
print("outputs/lapse_model.joblib")

# ----------------------------------
# Lapse Probability Scoring
# ----------------------------------

rfm["Lapse_Probability"] = best_model.predict_proba(X)[:, 1]

# ----------------------------------
# Retention List
# ----------------------------------

retention_list = rfm.sort_values(
    "Lapse_Probability",
    ascending=False
)

retention_list.to_csv(
    "outputs/retention_list.csv",
    index=False
)

print("\nRetention list saved:")
print("outputs/retention_list.csv")

# ----------------------------------
# Top 10 At-Risk Customers
# ----------------------------------

print("\nTop 10 At-Risk Customers")

print(
    retention_list[
        [
            "customer_id",
            "Recency",
            "Frequency",
            "Monetary",
            "Lapse_Probability"
        ]
    ].head(10)
)