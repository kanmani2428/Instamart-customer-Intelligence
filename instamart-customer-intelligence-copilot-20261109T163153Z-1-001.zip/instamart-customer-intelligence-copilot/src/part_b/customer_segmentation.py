import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# Load RFM table
rfm = pd.read_csv("outputs/rfm_table.csv")

print("Customers:", len(rfm))

# Features for clustering
features = rfm[["Recency", "Frequency", "Monetary"]]

# Scale data
scaler = StandardScaler()
scaled_features = scaler.fit_transform(features)

# Test different K values
print("\nK-Means Inertia Scores")

for k in range(2, 9):
    model = KMeans(
        n_clusters=k,
        random_state=42,
        n_init=10
    )

    model.fit(scaled_features)

    print(f"K={k} | Inertia={model.inertia_:.2f}")

# Final model
kmeans = KMeans(
    n_clusters=4,
    random_state=42,
    n_init=10
)

rfm["Cluster"] = kmeans.fit_predict(scaled_features)

# Cluster summary
cluster_summary = rfm.groupby("Cluster").agg({
    "Recency": "mean",
    "Frequency": "mean",
    "Monetary": "mean"
}).round(2)

print("\nCluster Summary")
print(cluster_summary)

# Simple segment naming
segment_names = {
    0: "High Value",
    1: "Loyal",
    2: "At Risk",
    3: "Regular"
}

rfm["Segment"] = rfm["Cluster"].map(segment_names)

print("\nSegment Distribution")
print(rfm["Segment"].value_counts())

# Save output
rfm.to_csv(
    "outputs/customer_segments.csv",
    index=False
)

print("\nSaved: outputs/customer_segments.csv")
