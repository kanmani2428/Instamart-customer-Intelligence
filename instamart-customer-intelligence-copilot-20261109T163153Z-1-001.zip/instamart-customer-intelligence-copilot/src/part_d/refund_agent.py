import pandas as pd

# =====================================
# Load Classified Tickets
# =====================================

tickets = pd.read_csv("outputs/triage_results.csv")

print("Tickets Loaded:", len(tickets))

# =====================================
# Refund Decision Engine
# =====================================

def refund_decision(category):

    if category == "fraud":
        return "APPROVED"

    elif category == "billing":
        return "APPROVED"

    elif category == "delivery":
        return "REVIEW"

    elif category == "technical":
        return "REJECTED"

    return "REVIEW"


def refund_priority(category):

    if category == "fraud":
        return "HIGH"

    elif category == "billing":
        return "MEDIUM"

    elif category == "delivery":
        return "MEDIUM"

    elif category == "technical":
        return "LOW"

    return "LOW"


def refund_amount(category):

    if category == "fraud":
        return 500

    elif category == "billing":
        return 300

    elif category == "delivery":
        return 100

    elif category == "technical":
        return 0

    return 0


def refund_comment(category):

    comments = {
        "fraud": "Fraud case detected. Escalate immediately and initiate refund.",
        "billing": "Billing issue verified. Refund can be processed.",
        "delivery": "Delivery complaint requires manual review.",
        "technical": "Technical issue does not qualify for refund.",
    }

    return comments.get(
        category,
        "Manual investigation required."
    )

# =====================================
# Apply Rules
# =====================================

tickets["refund_decision"] = (
    tickets["predicted_category"]
    .apply(refund_decision)
)

tickets["priority"] = (
    tickets["predicted_category"]
    .apply(refund_priority)
)

tickets["estimated_refund"] = (
    tickets["predicted_category"]
    .apply(refund_amount)
)

tickets["agent_comment"] = (
    tickets["predicted_category"]
    .apply(refund_comment)
)

# =====================================
# Summary
# =====================================

print("\nRefund Decisions")
print(
    tickets["refund_decision"]
    .value_counts()
)

print("\nPriority Distribution")
print(
    tickets["priority"]
    .value_counts()
)

print("\nEstimated Refund Liability")
print(
    f"INR {tickets['estimated_refund'].sum():,.2f}"
)

# =====================================
# Save Output
# =====================================

tickets.to_csv(
    "outputs/refund_decisions.csv",
    index=False
)

print("\nSaved:")
print("outputs/refund_decisions.csv")

# =====================================
# Sample Output
# =====================================

print("\nSample Decisions")

print(
    tickets[
        [
            "ticket_id",
            "predicted_category",
            "refund_decision",
            "priority",
            "estimated_refund"
        ]
    ].head(10)
)