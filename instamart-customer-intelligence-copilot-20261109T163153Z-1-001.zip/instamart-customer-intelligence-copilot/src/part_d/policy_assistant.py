import textwrap

# ======================================
# POLICY KNOWLEDGE BASE
# ======================================

POLICIES = {
    "refund": """
    Refund requests must be raised within 7 days of delivery.

    Eligible cases:
    - Damaged item
    - Missing item
    - Incorrect item delivered
    - Duplicate billing

    Refunds are usually processed within 5-7 business days.
    """,

    "delivery": """
    Standard delivery time is 24-48 hours.

    Customers may be eligible for compensation if:
    - Order is significantly delayed
    - Order is marked delivered but not received
    - Items are missing from delivery

    Delivery issues are handled by Customer Support.
    """,

    "fraud": """
    Fraud-related incidents are escalated immediately
    to the Security Team.

    Fraud indicators include:
    - Unauthorized transactions
    - Orders not placed by the customer
    - Suspicious account activity

    Accounts may be temporarily restricted during investigation.
    """,

    "billing": """
    Billing disputes are reviewed within 5 business days.

    Examples:
    - Incorrect invoice amount
    - Double charges
    - Unexpected deductions
    - Payment processing issues

    Eligible billing errors may receive a full refund.
    """,

    "technical": """
    Technical issues include:
    - App crashes
    - Login failures
    - Checkout errors
    - Payment page failures

    Technical tickets are routed to the Engineering Team.
    """
}


# ======================================
# POLICY SEARCH
# ======================================

def answer_policy_question(question):

    question = question.lower()

    if any(word in question for word in [
        "refund",
        "return",
        "money back"
    ]):
        return POLICIES["refund"]

    if any(word in question for word in [
        "delivery",
        "late",
        "courier",
        "rider"
    ]):
        return POLICIES["delivery"]

    if any(word in question for word in [
        "fraud",
        "unauthorized",
        "hacked",
        "security"
    ]):
        return POLICIES["fraud"]

    if any(word in question for word in [
        "billing",
        "charge",
        "charged",
        "invoice",
        "payment"
    ]):
        return POLICIES["billing"]

    if any(word in question for word in [
        "technical",
        "error",
        "crash",
        "login",
        "app"
    ]):
        return POLICIES["technical"]

    return """
    Sorry, I couldn't find a matching policy.

    Available policy topics:
    - Refund
    - Delivery
    - Fraud
    - Billing
    - Technical
    """


# ======================================
# INTERACTIVE CHAT MODE
# ======================================

print("=" * 60)
print("INSTAMART POLICY ASSISTANT")
print("=" * 60)

while True:

    question = input(
        "\nAsk a policy question (or type 'exit'): "
    )

    if question.lower() == "exit":
        print("\nGoodbye!")
        break

    answer = answer_policy_question(question)

    print("\nANSWER:")
    print(textwrap.dedent(answer).strip())