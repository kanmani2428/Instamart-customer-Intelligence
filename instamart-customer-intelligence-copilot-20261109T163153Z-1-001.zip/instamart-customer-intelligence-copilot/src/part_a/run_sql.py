import sqlite3
import pandas as pd

conn = sqlite3.connect("data/instamart.db")

query = """
SELECT
    p.category,
    ROUND(AVG(o.order_amount), 2) AS avg_order_value
FROM orders o
JOIN products p
    ON o.product_id = p.product_id
WHERE o.status = 'completed'
GROUP BY p.category
ORDER BY avg_order_value DESC
"""

result = pd.read_sql_query(query, conn)

print(result)

conn.close()