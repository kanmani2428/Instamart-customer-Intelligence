import pandas as pd

customers = pd.read_csv("data/raw/customers.csv")

customers["city"] = customers["city"].str.strip().str.title()

customers["gender"] = customers["gender"].replace({
    "male": "male",
    "Male": "male",
    "M": "male",
    "m": "male",
    "MALE": "male",

    "female": "female",
    "Female": "female",
    "F": "female",
    "f": "female",
    "FEMALE": "female"
})

customers["gender"] = customers["gender"].fillna("unknown")

customers["age"] = pd.to_numeric(customers["age"], errors="coerce")

customers.loc[
    (customers["age"] < 10) | (customers["age"] > 100),
    "age"
] = pd.NA

print("Missing Ages After Invalid Age Fix:", customers["age"].isna().sum())

customers["age"] = customers.groupby("city")["age"].transform(
    lambda x: x.fillna(x.median())
)

print("Minimum Age:", customers["age"].min())
print("Maximum Age:", customers["age"].max())

customers.to_csv("data/clean/customers.csv", index=False)
print("Clean customers file saved.")
