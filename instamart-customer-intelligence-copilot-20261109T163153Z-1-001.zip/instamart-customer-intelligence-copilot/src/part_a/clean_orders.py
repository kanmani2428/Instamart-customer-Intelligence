import pandas as pd

orders = pd.read_csv("data/raw/orders.csv")
products = pd.read_csv("data/raw/products.csv")

print("Orders:", orders.shape)
print("Products:", products.shape)

orders["order_ts"] = pd.to_datetime(orders["order_ts"])

print(orders["order_ts"].dtype)

orders = orders.drop_duplicates()

print("Rows After Removing Exact Duplicates:", len(orders))

orders = orders.sort_values("order_ts")

orders = orders.drop_duplicates(
    subset="order_id",
    keep="last"
)

print("Rows After Order ID Deduplication:", len(orders))

orders["order_amount"] = pd.to_numeric(
    orders["order_amount"],
    errors="coerce"
)

print(
    "Missing Order Amounts:",
    orders["order_amount"].isna().sum()
)

orders = orders.merge(
    products[["product_id", "price_inr"]],
    on="product_id",
    how="left"
)

print(orders.shape)

orders = orders.merge(
    products[["product_id", "category"]],
    on="product_id",
    how="left"
)

print(orders.shape)

calculated_amount = round(
    orders["price_inr"]
    * orders["quantity"]
    * (1 - orders["discount_pct"] / 100),
    2
)

orders["order_amount"] = orders["order_amount"].fillna(
    calculated_amount
)

print(
    "Missing Order Amounts After Fix:",
    orders["order_amount"].isna().sum()
)

print(
    orders[orders["order_amount"].isna()].shape
)

orders["delivery_minutes"] = pd.to_numeric(
    orders["delivery_minutes"],
    errors="coerce"
)

orders.loc[
    orders["delivery_minutes"] < 0,
    "delivery_minutes"
] = pd.NA

completed_mask = orders["status"] == "completed"

orders.loc[completed_mask, "delivery_minutes"] = (
    orders.loc[completed_mask]
    .groupby("category")["delivery_minutes"]
    .transform(lambda x: x.fillna(x.median()))
)

completed_missing = orders.loc[
    orders["status"] == "completed",
    "delivery_minutes"
].isna().sum()

cancelled_missing = orders.loc[
    orders["status"] == "cancelled",
    "delivery_minutes"
].isna().sum()

print("Missing Delivery - Completed:", completed_missing)
print("Missing Delivery - Cancelled:", cancelled_missing)

print(
    "Missing Delivery After Negative Fix:",
    orders["delivery_minutes"].isna().sum()
)


print(
    "Missing Delivery Before Fix:",
    orders["delivery_minutes"].isna().sum()
)

print(orders["status"].value_counts())

completed_revenue = orders.loc[
    orders["status"] == "completed",
    "order_amount"
].sum()

print("Completed Revenue:", round(completed_revenue, 2))

orders.to_csv(
    "data/clean/orders.csv",
    index=False
)

print("Clean orders file saved.")