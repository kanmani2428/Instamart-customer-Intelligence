import pandas as pd

products = pd.read_csv("data/raw/products.csv")

products.to_csv(
    "data/clean/products.csv",
    index=False
)

print("Clean products file saved.")