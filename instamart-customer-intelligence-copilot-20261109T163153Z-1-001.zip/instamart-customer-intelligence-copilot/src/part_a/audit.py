import pandas as pd

customers = pd.read_csv("data/raw/customers.csv")
products = pd.read_csv("data/raw/products.csv")
orders = pd.read_csv("data/raw/orders.csv")

print("Customers:", customers.shape)
print("Products:", products.shape)
print("Orders:", orders.shape)

duplicate_count = orders.duplicated().sum()
print("Exact Duplicate Rows:", duplicate_count)

pending_count = (orders["status"] == "pending").sum()
print("Pending Rows:", pending_count)

distinct_orders = orders["order_id"].nunique()
print("Distinct Order IDs:", distinct_orders)

invalid_amounts = pd.to_numeric(
    orders["order_amount"],
    errors="coerce"
).isna().sum()

print("Non-Numeric Amounts:", invalid_amounts)

negative_delivery = (
    pd.to_numeric(
        orders["delivery_minutes"],
        errors="coerce"
    ) < 0
).sum()

print("Negative Delivery Times:", negative_delivery)

blank_delivery = orders["delivery_minutes"].isna().sum()
print("Blank Delivery Times:", blank_delivery)

blank_age = customers["age"].isna().sum()
print("Blank Ages:", blank_age)

invalid_age = (
    (customers["age"] < 10) |
    (customers["age"] > 100)
).sum()

print("Invalid Ages:", invalid_age)

city_spellings = customers["city"].nunique()
print("Distinct Raw City Spellings:", city_spellings)

gender_spellings = customers.loc[
    customers["gender"].notna(),
    "gender"
].nunique()

print("Distinct Non-Blank Gender Spellings:", gender_spellings)

blank_gender = customers["gender"].isna().sum()
print("Blank Gender:", blank_gender)