import pandas as pd

# Load tickets data
tickets = pd.read_csv("data/raw/tickets.csv")

# Basic information
print("=" * 50)
print("TICKETS DATASET AUDIT")
print("=" * 50)

print("\nShape:")
print(tickets.shape)

print("\nColumns:")
print(tickets.columns.tolist())

print("\nData Types:")
print(tickets.dtypes)

print("\nFirst 5 Records:")
print(tickets.head())

print("\nMissing Values:")
print(tickets.isna().sum())

print("\nDuplicate Rows:")
print(tickets.duplicated().sum())

print("\nUnique Values Per Column:")
for col in tickets.columns:
    print(f"{col}: {tickets[col].nunique()}")

print("\nDataset Audit Complete")