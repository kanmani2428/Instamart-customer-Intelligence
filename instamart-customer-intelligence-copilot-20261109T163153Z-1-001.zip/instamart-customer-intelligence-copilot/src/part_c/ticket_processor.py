import pandas as pd
import re

# ======================================
# Load Data
# ======================================

tickets = pd.read_csv("data/raw/tickets.csv")

print("Original Tickets:", len(tickets))

# ======================================
# Remove Empty Tickets
# ======================================

tickets = tickets[tickets["text"].notna()].copy()

print("Valid Tickets:", len(tickets))

# ======================================
# PII Redaction
# ======================================

def redact_text(text):

    text = str(text)

    # Email addresses
    text = re.sub(
        r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
        "[EMAIL]",
        text
    )

    # Phone numbers
    text = re.sub(
        r"\b\d{10}\b",
        "[PHONE]",
        text
    )

    # Order IDs
    text = re.sub(
        r"ORD-\d+",
        "[ORDER_ID]",
        text
    )

    return text


tickets["redacted_text"] = tickets["text"].apply(redact_text)

# ======================================
# Ticket Classification
# ======================================

def classify_ticket(text):

    text = str(text).lower()

    # FRAUD
    if any(keyword in text for keyword in [
        "unauthorized",
        "stolen",
        "hacked",
        "fraudulent",
        "suspicious transaction",
        "account hacked",
        "someone accessed my account",
        "never placed",
        "did not place",
        "didn't place",
        "i never placed",
        "charged for order",
        "unknown order"
    ]):
        return "fraud"

    # DELIVERY
    if any(keyword in text for keyword in [
        "delivery",
        "late",
        "delivered",
        "rider",
        "missing item",
        "order not received",
        "wrong item delivered",
        "delivery delay"
    ]):
        return "delivery"

    # TECHNICAL
    if any(keyword in text for keyword in [
        "app",
        "crash",
        "crashed",
        "error",
        "login",
        "unable to open",
        "technical",
        "page froze",
        "app froze",
        "website error",
        "server error"
    ]):
        return "technical"

    # BILLING
    if any(keyword in text for keyword in [
        "charged twice",
        "invoice",
        "amount",
        "refund",
        "billing",
        "deducted",
        "overcharged",
        "extra money",
        "wrong amount",
        "double charge"
    ]):
        return "billing"

    return "other"


tickets["predicted_category"] = (
    tickets["redacted_text"]
    .apply(classify_ticket)
)

# ======================================
# Routing Rules
# ======================================

route_map = {
    "fraud": "Security Team",
    "billing": "Finance Team",
    "technical": "Engineering Team",
    "delivery": "Customer Support",
    "other": "General Queue"
}

tickets["route"] = tickets["predicted_category"].map(route_map)

# ======================================
# Summary
# ======================================

print("\nPredicted Categories")
print(tickets["predicted_category"].value_counts())

print("\nRoutes")
print(tickets["route"].value_counts())

# ======================================
# Save Results
# ======================================

tickets.to_csv(
    "outputs/triage_results.csv",
    index=False
)

print("\nSaved: outputs/triage_results.csv")

# ======================================
# Preview
# ======================================

print("\nSample Output")

print(
    tickets[
        [
            "ticket_id",
            "true_category",
            "predicted_category",
            "route",
            "redacted_text"
        ]
    ].head(10)
)