import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

# ----------------------------------
# Load Results
# ----------------------------------

df = pd.read_csv("outputs/triage_results.csv")

print("Total Tickets:", len(df))

# ----------------------------------
# Compare Actual vs Predicted
# ----------------------------------

y_true = df["true_category"]
y_pred = df["predicted_category"]

# ----------------------------------
# Accuracy
# ----------------------------------

accuracy = accuracy_score(y_true, y_pred)

print("\nAccuracy:", round(accuracy, 4))

# ----------------------------------
# Classification Report
# ----------------------------------

print("\nClassification Report")
print(
    classification_report(
        y_true,
        y_pred,
        zero_division=0
    )
)

# ----------------------------------
# Confusion Matrix
# ----------------------------------

labels = sorted(
    list(
        set(y_true) |
        set(y_pred)
    )
)

cm = confusion_matrix(
    y_true,
    y_pred,
    labels=labels
)

cm_df = pd.DataFrame(
    cm,
    index=labels,
    columns=labels
)

print("\nConfusion Matrix")
print(cm_df)

# ----------------------------------
# Correct vs Incorrect
# ----------------------------------

df["correct"] = (
    df["true_category"]
    ==
    df["predicted_category"]
)

correct_count = df["correct"].sum()
incorrect_count = len(df) - correct_count

print("\nCorrect Predictions:", correct_count)
print("Incorrect Predictions:", incorrect_count)

# ----------------------------------
# Save Misclassified Tickets
# ----------------------------------

errors = df[
    df["true_category"]
    !=
    df["predicted_category"]
].copy()

errors.to_csv(
    "outputs/misclassified_tickets.csv",
    index=False
)

print("\nMisclassified tickets saved:")
print("outputs/misclassified_tickets.csv")

# ----------------------------------
# Sample Errors
# ----------------------------------

print("\nSample Misclassifications")

if len(errors) > 0:
    print(
        errors[
            [
                "ticket_id",
                "true_category",
                "predicted_category",
                "text"
            ]
        ].head(10)
    )
else:
    print("No classification errors found.")